// 1.  

function padLeft(padding : number | string , input : string) : string{
    if( typeof padding === "number" ){
       return " ".repeat(padding) + input
    }
    return padding + input
}


// falsy value 
// 0
// NaN
// "" (the empty string)
// 0n (the bigint version of zero)
// null
// undefined


function multiplyAll(
  values: number[] | undefined,
  factor: number
): number[] | undefined {
  if (!values) {
    return values;
  } else {
    return values.map((x) => x * factor);
  }
}

// console.log(multiplyAll( [1,2,3] , 2 ))

// in operator narrowing

type Fish = { swim : ()=>void}
type Bird = { fly : ()=>void}
type Human1 = { swim? : ()=> void ; fly?:()=> void }
function move( animal : Fish | Bird | human ){
    if( "swim" in animal ) return animal;
    return animal
}

// instanceof  

function logValue( x : Date | string ){
    if( x instanceof Date){
        console.log(x.toUTCString())
    }
    else{
        console.log(x.toLowerCase())
    }
}

// Using type predicates
function isFish(pet:Fish | Bird ) : pet is Fish{
    return (pet as Fish).swim !== undefined
}

//The never type 


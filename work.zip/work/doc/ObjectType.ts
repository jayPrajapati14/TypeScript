// function greet(person: { name: string; age: number }) {
//   return "Hello " + person.name;
// }

// IMP
// interface Home {
//   readonly resident: { name: string; age: number };
// }
 
// function visitForBirthday(home: Home) {

//   home.resident.age++;
// }
 
// function evict(home: Home) {
  
// //   home.resident = {
// //     name: "Victor the Evictor",
// //     age: 42,
// //   };
// }


//index signatures
// 1
// interface StringArray {
//   [index: number]: string;
// }
 
// const myArray: StringArray = getStringArray();
// const secondItem = myArray[1];


// interface StringArray {
//   [index: number]: string;
// }


// function getStringArray(): string[] {
//   return ["apple", "banana", "cherry"];
// }

// const myArray: StringArray = getStringArray();


// const secondItem = myArray[1];

// console.log(secondItem); 

// interface Colorful {
//   color: string;
// }
// interface Circle {
//   radius: number;
// }

// // intersaction just name but perform like AND
// type ColorfulCircle = Colorful & Circle;
// const oo : ColorfulCircle = { color : "black" , radius:12} 

interface Person1 {
  name: string;
}
 
interface Person2 {
  name: number;
}
 
type Staff = Person1 & Person2
 
declare const staffer: Staff;

staffer.name;


"use strict";
// function firstElement<T>(arr: T[]): T {
//   return arr[0];
// }
const pair = { first: 1, second: 1 };
console.log(pair);

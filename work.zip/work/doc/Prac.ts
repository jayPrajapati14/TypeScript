// function firstElement<T>(arr: T[]): T {
//   return arr[0];
// }

// const firstNum = firstElement([10, 20, 30]);      
// const firstChar = firstElement(['a', 'b', 'c']);

// console.log(firstNum);  
// console.log(firstChar); 


// function merge<T, U>(obj1: T, obj2: U): T & U {
//   return { ...obj1, ...obj2 };
// }

// const merged = merge({ name: "Alice" }, { age: 30 });
// // merged: { name: string; age: number }

// console.log(merged); // { name: 'Alice', age: 30 }

// function swap<T, U>(a: T, b: U): [U, T] {
//   return [b, a];
// }

// const result = swap("hello", 42);  // [42, "hello"]
// console.log(result);



// interface Box<T> {
//   value: T;
// }

// const stringBox: Box<string> = { value: "Books" };
// const numberBox: Box<number> = { value: 123 };

// console.log(stringBox.value);  
// console.log(numberBox.value);  

// class Container<T> {
//   private content: T;

//   constructor(value: T) {
//     this.content = value;
//   }

//   getContent(): T {
//     return this.content;
//   }
// }

// const numContainer = new Container<number>(100);
// const strContainer = new Container<string>("Hello");

// console.log(numContainer.getContent()); 
// console.log(strContainer.getContent()); 

// function getLength<T extends { length : number}>(item: T): number {
//   return item.length;
// }

// console.log(getLength("Hello"));        
// console.log(getLength([1, 2, 3]));

// function gre<T = string>(name: T): void {
//   console.log("Hello", name);
// }

// gre();          
// gre("World");   
// gre(123);      

interface Pair<T> {
  first: T;
  second: T;
}

const pair: Pair<number> = { first: 1, second: 1 };

console.log(pair); 
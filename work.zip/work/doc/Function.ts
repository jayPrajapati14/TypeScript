// Generic Functions

// 1. Identity Function
// function identity<T>(value : T):T{
//     return value;
// }

// const num = identity<number>(10);
// console.log(num);
// const str = identity<string>("hello");
// console.log(str);

// 2. working with array 
// function getFirstElement<T>(arr:T[]) : T | undefined {
//     return arr[0]
// }

// const firstEle = getFirstElement<number>([1,2,3]);
// console.log(firstEle)
// const firststr = getFirstElement<string>(["A" , "b" , "c"])
// console.log(firststr)

// 3. swap two value
// function swap<T,U>(a:T,b:U):[U,T]{
//     return [b,a]
// }

// const swapped = swap<string , number>("hello",42);
// console.log(swapped);

// 4. Generic with Constraints
// function logLength<T extends {length:number}> (item : T) : void {
//     console.log(item.length);
// }

// logLength("hellow")
// logLength([1,2,3])

// 5. Generic Function to Merge Objects
// function mergeObjects<T, U>(obj1: T, obj2: U): T & U {
//   return { ...obj1, ...obj2 };
// }

// const merged = mergeObjects({ name: "Raj"  , sname : 1 }, { age: 25 , sage:"20"});
// console.log(merged);

// 6 
// function map<Input, Output>(arr: Input[], func: (arg: Input) => Output): Output[] {
//   return arr.map(func);
// }

// const parsed = map(["1", "2", "3"], (n) => parseInt(n));

// console.log(parsed);

// Constraints
// function longest<Type extends { length: number }>(a: Type, b: Type) : Type{
//   if (a.length >= b.length) {
//     return a;
//   } else {
//     return b;
//   }
// }
 
// // longerArray is of type 'number[]'
// const longerArray = longest([1, 2], [1, 2, 3]);
// console.log(longerArray)
// // longerString is of type 'alice' | 'bob'
// const longerString = longest("alice", "bob");
// console.log(longerString)
// // Error! Numbers don't have a 'length' property
// // const notOK = longest(10, 100);

// function minimumLength<Type extends { length: number }>(
//   obj: Type,
//   minimum: number
// ) :  Type | boolean {
//   if (obj.length >= minimum) {
//     return obj;
//   } else {
//     return false;
//   }
// }

// function combine<Type , Type2>(arr1: Type[], arr2: Type2[]): ( Type | Type2 )[] {
//   return arr1.concat(arr2);
// }

// const arr = combine([1, 2, 3], ["hello"]);


// Optional Parameters
// function myForEach<T>(arr: T[], callback: (arg: T, index?: number) => void) {
//   for (let i = 0; i < arr.length; i++) {
//     callback(arr[i] , i);
//   }
// }

// myForEach([1,2,3] , ( a , i )=>{
//     console.log(a,i);
// })

// function makeDate(timestamp: number): Date;
// function makeDate(m: number, d: number, y: number): Date;
// function makeDate(mOrTimestamp: number, d?: number, y?: number): Date {
//   if (d !== undefined && y !== undefined) {
//     return new Date(y, mOrTimestamp, d);
//   } else {
//     return new Date(mOrTimestamp);
//   }
// }
// const d1 = makeDate(12345678);
// const d2 = makeDate(5, 5, 5);
// const d3 = makeDate(1, 3);

// function len(s: string): number;
// function len(arr: any[]): number;
// function len(x: any) {
//   return x.length;
// }

// len(""); 
// len([0]); 

// // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// len(Math.random() > 0.5 ? "hello" : [0]);

this

const userJay = {
  id: 123,
 
  admin: false,
  becomeAdmin: function () {
    this.admin = true;
  },
};

console.log(userJay)

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1111
// interface DB {
//   filterUsers(filter: (this: User) => boolean): User[];
// }
 
// const db = getDB();
// const admins = db.filterUsers(function (this: User) {
//   return this.admin;
// });

// never => never return any value


// Parameter Destructuring

// if i ave one object and i want to access directly any vakue from key so i use 
// { key } and directly get 

// const o = {
//     name:"jay",
//     agej:23
// };

// const { agej } = o;
// console.log(agej);

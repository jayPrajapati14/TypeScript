"use strict";
// 1.  
function padLeft(padding, input) {
    if (typeof padding === "number") {
        return " ".repeat(padding) + input;
    }
    return padding + input;
}
// falsy value 
// 0
// NaN
// "" (the empty string)
// 0n (the bigint version of zero)
// null
// undefined
function multiplyAll(values, factor) {
    if (!values) {
        return values;
    }
    else {
        return values.map((x) => x * factor);
    }
}
function move(animal) {
    if ("swim" in animal)
        return animal;
    return animal;
}
// instanceof  
function logValue(x) {
    if (x instanceof Date) {
        console.log(x.toUTCString());
    }
    else {
        console.log(x.toLowerCase());
    }
}
// Using type predicates
function isFish(pet) {
    return pet.swim !== undefined;
}
//The never type 

"use strict";
// function greet(person: { name: string; age: number }) {
//   return "Hello " + person.name;
// }
function getStringArray() {
    return ["apple", "banana", "cherry"];
}
const myArray = getStringArray();
const secondItem = myArray[1];
console.log(secondItem);

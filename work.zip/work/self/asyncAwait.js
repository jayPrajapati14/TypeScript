"use strict";
// case 1  Basic Example
async function ipl() {
    return "ipl";
}
async function display() {
    const data = await ipl();
    console.log(data);
}
// display();
// case 2 Handling Promises with Async/Await
function delay(ms) {
    console.log("start");
    return new Promise(resolve => setTimeout(() => resolve("over"), ms));
}
async function processData() {
    console.log('Start processing...');
    let data = await delay(2000);
    console.log(data);
    console.log('data processed');
}
// processData();
// case 3 Async/Await with Error Handling
async function fetchdata() {
    // throw new Error("something went wrong")'
    //When an error is thrown inside an async function, 
    // it automatically returns a rejected promise (just like how reject() 
    // works in the traditional Promise constructor). The error you throw 
    // is used as the reason for the rejection
    return new Promise((reject) => reject("something wrong"));
}
async function handleData() {
    try {
        const data = await fetchdata();
        console.log(data);
    }
    catch (error) {
        console.log(error);
    }
}
// handleData()
// case 4 Using async with Multiple Promises
function fetchUserData() {
    return new Promise(resolve => setTimeout(() => {
        resolve("user data");
    }, 1000));
}
function fetchProductData() {
    return new Promise(resolve => setTimeout(() => resolve("Product data"), 1000));
}
async function fetchAllData() {
    const userData = await fetchUserData();
    const productData = await fetchProductData();
    console.log(userData);
    console.log(productData);
}
// fetchAllData()
// case 5 Using Promise.all with Async/await 
async function fetchUserDatatest() {
    return new Promise(resolve => setTimeout(() => resolve("User data"), 1000));
}
async function fetchProductDatatest() {
    return new Promise(resolve => setTimeout(() => resolve("Product data"), 1500));
}
async function fetchAllData5() {
    const [userData, productData] = await Promise.all([fetchUserDatatest(), fetchProductDatatest()]);
    console.log(userData);
    console.log(productData);
}
fetchAllData5();
// case 6 Async/Await with JSON Fetching
async function fetchJsonData(url) {
    const response = await fetch(url);
    const data = await response.json();
    return data;
}
async function displayJsonData() {
    const url = "https://jsonplaceholder.typicode.com/todos/1";
    const data = await fetchJsonData(url);
    console.log(data);
}
async function fetchUserById(id) {
    const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`);
    const data = await response.json();
    return data;
}
async function showUserData() {
    const user = await fetchUserById(1);
    console.log(user.name);
}
// showUserData();
// case 8 Using Async/Await with a For Loop
function simulateRequest(id) {
    return new Promise(resolve => setTimeout(() => resolve(`Request ${id} completed`), 1000));
}
async function processRequests() {
    for (let i = 1; i <= 3; i++) {
        const result = await simulateRequest(i);
        console.log(result);
    }
}
// processRequests();

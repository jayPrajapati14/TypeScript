class Person {
    name: string;
    age:number

    constructor(n1 : string ,n2 : number){
        this.name = n1;
        this.age = n2
    }
}

const j1 = new Person("Rohit" , 20);
const j2 = new Person("jay", 20);
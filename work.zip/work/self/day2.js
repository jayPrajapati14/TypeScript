"use strict";
// interface and type more 
const abj = {
    name: "jay",
    age: 20,
    // gender:"male"
};
const arr = [{ name: "jay", age: 29 }, { name: "jay", age: 29 }];
// function in ts
function greet(a) {
    console.log(a);
    return a;
}
function meet(msg, val) {
    console.log(msg, val);
}
const o1 = [{ name: "jay", age: 20 }, { name: "jay" }, { age: 23 }];
// default parameter 
function neet(msg = "jit") {
    console.log(msg);
}
neet();
function jee(msg) {
    console.log(msg ? msg : "nothing");
}
jee();
const sum = (a, b) => {
    return a + b;
};
// callback function 
function placeorder(order, callback) {
    const amount = order + 10;
    callback(amount);
}
placeorder(10, (value) => {
    console.log(value);
});
function placeorder2(order, callback) {
    const amount = order;
    callback(amount, amount);
}
placeorder2(10, (a, b) => {
    console.log(a, b);
});
function placeorder3(val, callback) {
    console.log(val);
    callback({ a: 10, b: 20 });
}
function placeorder4(val, callback) {
    console.log(val);
    callback({ a: 10, b: 20 });
}
// rest parameter
function total(...arr) {
    let ans = 0;
    for (let i = 0; i < arr.length; i++)
        ans += arr[i];
    console.log(ans);
}
total(1, 2, 3, 4, 5, 6);
;
;
;
const jay = {
    name: "jay",
    age: 23,
    hand: 3
};
const jay2 = {
    name: "jay",
    age: 23,
    hand: 3,
    leg: 4
};
// const t1:teacher = {
//     type:"top",
//     salary:200,
//     name:"jay",
//     age:20
// }

"use strict";
let user = "jay";
console.log(user);
let age = 24;
console.log(age);
let salary = 240000000043234n;
salary = 2100000000000000n;
console.log(salary);
let isUser = true;
isUser = false;
console.log(isUser);
// je value aapi hoy aena hisabe type lai le
let seconduser = "jay2"; // direct have aa jevi value thi initilize karyu aevi type aapi de
console.log(typeof seconduser);
// seconduser = 20; error aai de same type aapvu pade
// IMPORTANT : any type aapi de jo aapde initilize na kariye to js jevu kam kare
let list;
list = "jay";
list = 3;
console.log(list);
if (typeof list === "string") {
    console.log("string");
}
else if (typeof list === "number") {
    console.log("number");
}
let value;
value = "jay";
// value = 20;
console.log(value);
if (typeof value === "string") {
    console.log("string");
}
else if (typeof value === "number") {
    console.log("number");
}
//                            ANY VS UNKNOWN
/* any ae defalut aene js jevi func.. aapi de jyare aapde multiple case
handle karva hoy like typeof number to this and typeof string so this tyre
aapde unknown no use kariye 6iye

any ma aapde direct badha function use kari hakiye 6iye like uppercase but what if
mari pase number hoy to hu kemnu uppercase lagavu jayre unknow ae permison aaptu nathi
pela aapde type check kariye pa6i j so unknow better

and any no use naj thay to saru code ma
*/
//    Array
let array = [1, 2, 3, 4];
console.log(typeof array);
let array2 = [1, 2, 3, 4];
console.log(typeof array2[0]);
// now if i want to string and number both in array so
let array3 = [1, "two"];
// List   -> same array just fix number of value in array
let list2 = [1, 2];
let list3 = [1, "jay", 1];
//   Object
let obj1 = {
    name: "jay",
    age: 24
};
console.log(obj1);
let person;
person = {
    name: "jay",
    age: 12
};
let c1 = {
    name: "jay",
    age: 24,
    id: "123"
};
let obj3 = {
    id: 12,
    name: "jay",
    age: 24,
    position: "top"
};
/*always use interface kemke aapde oops no ise karine 2 interface ke 3
interface n use kari ne aapde code ne saro banavi shakiye 6e */
// generic type
function getFirstElement(arr) {
    return arr[0];
}

"use strict";
let product_data = [
    { id: 1, name: "p1", price: 100 },
    { id: 2, name: "p2", price: 100 },
    { id: 3, name: "p3", price: 100 },
    { id: 4, name: "p4", price: 100 },
    { id: 5, name: "p5", price: 100 },
    { id: 6, name: "p6", price: 100 },
    { id: 7, name: "p7", price: 100 },
    { id: 8, name: "p8", price: 100 },
    { id: 9, name: "p9", price: 100 },
    { id: 10, name: "p10", price: 100 },
    { id: 11, name: "p11", price: 100 }
];
let cart = {
    id: 1,
    products: [],
};
async function getCart() {
    return new Promise((resolve, reject) => {
        setTimeout(() => resolve(cart), 2000);
    });
}
async function getCartData() {
    const data = await getCart();
    console.log(data);
}
// getCartData();
// add product
async function addProduct(obj) {
    return new Promise((resolve, reject) => {
        console.log("IO", cart.products.length);
        if (cart.products.length >= 10) {
            reject({ rStatus: false, code: 400, msg: "product not add!" });
        }
        cart.products.push(obj);
        setTimeout(() => {
            resolve({ rStatus: true, code: 200, msg: "product added!" });
        }, 1000);
    });
}
async function addProductToCart(obj) {
    const data = await addProduct(obj);
    console.log("ADD RESPONSE", data);
}
// getCartData();
// get Productbyid
async function getProductByID(id) {
    return new Promise((resolve, reject) => {
        const data = cart.products.find((ele) => ele.id === id);
        if (data) {
            setTimeout(() => {
                resolve(data);
            }, 1000);
        }
        else {
            setTimeout(() => {
                reject({ rStatus: false, code: 400, msg: "Product not found" });
            }, 1000);
        }
    });
}
async function findProduct(id) {
    const data = await getProductByID(id);
    console.log("GET ID RESPONSE", data);
}
// delete product
async function deletePRoduct(id) {
    return new Promise((resolve, reject) => {
        const idIndex = cart.products.findIndex((produ) => produ.id === id);
        if (idIndex != -1) {
            cart.products.splice(idIndex, 1);
            setTimeout(() => {
                resolve({ rStatus: true, code: 201, msg: "product deleted!" });
            }, 1000);
        }
        else {
            setTimeout(() => {
                reject({ rStatus: false, code: 400, msg: "Product not found" });
            });
        }
    });
}
async function deleteFromCart(id) {
    const data = await deletePRoduct(id);
    console.log("DELETE RESPONSE ", data);
}
// getCartData();
async function add10Product() {
    product_data.forEach(async (data) => {
        await addProductToCart(data).catch((error) => {
            console.log(error);
        });
    });
}
add10Product();
// addProductToCart({ id: 1, name: "p1", price: 100 }).catch((error)=>{
//     console.log(error)
// });
// addProductToCart({ id: 2, name: "p2", price: 200 }).catch((error)=>{
//     console.log(error)
// });
findProduct(1).catch((error) => {
    console.log(error);
});
deleteFromCart(1).catch((error) => {
    console.log(error);
});
getCartData();

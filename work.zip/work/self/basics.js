"use strict";
// let newVal : "jay" = "jay";
// newVal = "meet"
// console.log(newVal);
function isHuman(x) {
    return 'age' in x;
}
const a = { name: "Alice" };
console.log("..", isHuman(a));
if (isHuman(a)) {
    console.log(a.age);
}

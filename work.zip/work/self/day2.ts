// interface and type more 

interface Person {
    name:string,
    age:number,
    gender?:string  //optional 
}

const abj:Person = {
    name:"jay",
    age:20,
    // gender:"male"
}

interface custome {
    name : string,
    age:number,
    balance:number
}

// aama aapde koi koi value na aapiye to bhi chale
// const obje2 = Partial<custome> = {
//   name : "jay",
//   balance : 210
// }
// badhi value aapvi j pade
// const obje3 = Required<custome> = {
//   name : "jay",
//   balance : 210,
//   age:20
// }

// ak var value aaapya pa6i change thay nai
// const obje4 = Readonly<custome> = {
//   name : "jay",
//   balance : 210,
//   age:20
// }

//Array of object
interface people {
    name:string,
    age:number
}

const arr : people[] = [{name:"jay" , age : 29},{name:"jay" , age : 29}]

// function in ts
function greet(a : number) : number{
    console.log(a);
    return a;
}

function meet(msg: string , val:number) : void {
    console.log(msg , val)
}

// union

interface i1 {
    name:string
}

interface i2 {
    age:number
}

const o1 : (i1 | i2)[]  = [{name:"jay" , age:20 } , {name:"jay"} , {age:23}]


// default parameter 
function neet(msg : string = "jit" ):void {
    console.log(msg)
}

neet();

function jee(msg?: string ){
    console.log(msg ? msg : "nothing")
}

jee();

const sum = ( a : number , b : number ) : number => {
   return a+b;
}


// callback function 
function placeorder(order:number ,callback : (val : number)=>void) : void{
  
    const amount : number = order + 10;
    callback(amount);

}

placeorder(10 , (value : number)=>{
    console.log(value)
})

function placeorder2(order:number ,callback : (a:number , b : number)=>void) : void{
  
    const amount : number = order
    callback(amount , amount);

}

placeorder2(10, (a:number , b : number )=>{
    console.log(a,b)
});


function placeorder3( val : number , callback : ( obj :  { a : number , b : number} ) => void  ) : void {

    console.log(val);
    callback({a:10,b:20});
}

// also write with type

type mytype = (obj : { a : number , b : number}) => void

function placeorder4( val : number , callback : mytype): void {

    console.log(val);
    callback({a:10,b:20});
}


// rest parameter
function total(...arr : number[]){
   let ans : number = 0;  
   for(let i : number = 0 ; i < arr.length ; i++)ans+=arr[i];
   console.log(ans);
}

total(1,2,3,4,5,6);

// extand keyword 

interface human {
    name:string,
    age:number
};

interface human2 {
    leg:number,
    hand:number
};
interface teacher extends human , human2  {
     type:string,
     salary:number
};

const jay : human | human2 = {
    name:"jay",
    age:23,
    hand:3
}

const jay2 : human & human2 = {
    name:"jay",
    age:23,
    hand:3,
    leg:4
}



// const t1:teacher = {
//     type:"top",
//     salary:200,
//     name:"jay",
//     age:20
// }

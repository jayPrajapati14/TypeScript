// let newVal : "jay" = "jay";
// newVal = "meet"
// console.log(newVal);


// interface Options {
//     width : number
// }

// function cnf(x:Options | "auth"):void {
//     console.log("Call")
// }

// cnf("auth")
// cnf( {width:10} )

type Animal = {
    name:string
}

type Human = {
    name:string,
    age:number
}

function isHuman( x: Animal | Human ) : x is Human {
    return 'age' in x;
}

const a: Animal | Human = { name: "Alice"};

console.log(".." , isHuman(a));
if (isHuman(a)) {
  console.log(a.age); 
}
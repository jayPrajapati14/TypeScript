function debounce(fn , delay){
    let timerId;

    return function (...args){
        clearTimeout(timerId);
        timerId = setTimeout(()=>{
            fn(...args);
        } , delay);
    }
}

const search = (query)=>{

   console.log(query);

}

const searchWithDebounce =  debounce(search , 1000);

searchWithDebounce('h');
searchWithDebounce('ha');
searchWithDebounce('har');
searchWithDebounce('hard');
searchWithDebounce('hard ');
searchWithDebounce('hard j');
searchWithDebounce('hard js');



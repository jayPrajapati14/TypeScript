function myfun( fn , delay ){
    
    let timerId;

    return function (...args){
        clearTimeout(timerId);
        timerId = setTimeout(()=>{
            fn(...args);
        } , delay)
    }
}

const search = (query)=>{
    console.log(query);
}

const mycall = myfun( search , delay );

search("c");
search("co");
search("code");
search("code ");
search("code w");

